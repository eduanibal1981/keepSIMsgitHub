import 'dart:async';
import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:keep_sims/backend/fulfillment/data/repositories/supabase_refill_request_repository.dart';
import 'package:keep_sims/backend/fulfillment/data/repositories/supabase_system_config_repository.dart';
import 'package:keep_sims/backend/fulfillment/application/services/fulfillment_router_service.dart';
import 'package:keep_sims/backend/fulfillment/domain/entities/refill_request.dart';

/// Entry point for the Dart backend daemon running on the VPS.
Future<void> main() async {
  // Read environment variables (e.g., from .env)
  final supabaseUrl =
      Platform.environment['SUPABASE_URL'] ?? 'YOUR_SUPABASE_URL';
  final supabaseAnonKey =
      Platform.environment['SUPABASE_ANON_KEY'] ?? 'YOUR_SUPABASE_ANON_KEY';

  // Note: For a backend daemon that bypasses RLS for routing, you should ideally use the SERVICE_ROLE_KEY.
  // We use standard initialization here. If you need elevated access, provide the service_role key.

  print('Initializing Supabase connection...');
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);

  final supabase = Supabase.instance.client;

  // Initialize dependencies
  final refillRepo = SupabaseRefillRequestRepository(supabase);
  final configRepo = SupabaseSystemConfigRepository(supabase);
  final routerService = FulfillmentRouterService(refillRepo, configRepo);

  print('Fulfillment Router Service listening for new refill requests...');

  // Setup Realtime listener for NEW inserts in public.refill_requests
  supabase
      .channel('public:refill_requests:inserts')
      .onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public',
        table: 'refill_requests',
        callback: (payload) async {
          final newRecord = payload.newRecord;
          print('New Refill Request detected: ${newRecord['id']}');
          final request = RefillRequest.fromJson(newRecord);

          // Only route requests that are initially 'pending'
          if (request.status == 'pending') {
            await routerService.routeRequest(request);
          }
        },
      )
      .subscribe((status, [error]) {
        if (status == RealtimeSubscribeStatus.subscribed) {
          print('Successfully subscribed to Realtime stream.');
        } else if (status == RealtimeSubscribeStatus.closed) {
          print('Realtime stream closed.');
        } else if (status == RealtimeSubscribeStatus.channelError) {
          print('Realtime channel error: $error');
        }
      });

  // Keep the process alive indefinitely
  await Completer<void>().future;
}
